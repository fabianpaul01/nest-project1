import {
  Module,
  NestModule,
  MiddlewareConsumer,
  RequestMethod,
} from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { BlogsService } from './blogs/blogs.service';
import { AuthMiddleware } from './middleware/auth';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JiraRequestModule } from './response-time-tracking-jira/jira-request-module.module';
import { ConfigModule } from '@nestjs/config';
import { ExampleModule } from './example/example.module';

@Module({
  imports: [
    ConfigModule.forRoot(),
    JiraRequestModule,
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: 'Shard@123!!',
      database: 'Carestack_PMS',
      entities: ['dist/**/*.entity{.ts,.js}'],
      synchronize: true,
    }),
    ExampleModule,
  ],
  controllers: [AppController],
  providers: [AppService, BlogsService],
})

export class AppModule {}
// export class AppModule implements NestModule {
//   // configure(consumer: MiddlewareConsumer) {
//   //   consumer.apply(AuthMiddleware).forRoutes('*');
//   // }
// }
