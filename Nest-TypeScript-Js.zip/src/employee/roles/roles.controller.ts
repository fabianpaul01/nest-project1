import { Controller, Get } from '@nestjs/common';

@Controller('roles')
export class RolesController {
    @Get()
    rolesHistory():string{
        return "Roles History"
    }

    @Get("demo-page")
    rolesHistoryDemoPage():string{
        return "Roles History Demo Page"
    }
}
