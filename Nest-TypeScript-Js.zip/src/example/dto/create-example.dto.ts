export class CreateExampleDto {

    id:string

    firstName: string

    lastName:string

    isActive:boolean
}
