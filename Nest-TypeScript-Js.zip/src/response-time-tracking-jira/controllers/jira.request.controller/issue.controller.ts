import { Controller, Get, Post } from "@nestjs/common";
import { IssueService } from "src/response-time-tracking-jira/services/jira-request-services/issue.service";


@Controller('issues')
export class IssueController {

    constructor(private issueService : IssueService){}

    @Get()
    async getIssueResponse():Promise<any>{

      const result = this.issueService.get('search');
      console.log('In Controller:::');
      //console.log(JSON.stringify(result));

      return (await result).data;
    }

    @Post()
    async getPostResponse():Promise<any>{
      const result = await this.issueService.post('search',{"fields": ["*all"],"expand": ["changelog"]});
      console.log('In Controller:::');
      //console.log(JSON.stringify(result));

      return (result);
    }
}