export class CreateIssueDto {

    summary:string
    key:number
    changelog:any[]
}