export class CreateUserDto {

    id: string

    firstName: string;
  
    lastName: string;
  
    isActive: boolean;
  
}