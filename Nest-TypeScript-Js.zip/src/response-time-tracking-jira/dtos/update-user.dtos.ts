export class UpdateUserDto{
    firstName: string

    lastName: string

    isActive: boolean
}