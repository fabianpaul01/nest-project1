import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import axios from "axios";
import { CreateIssueDto } from "src/response-time-tracking-jira/dtos/create-issue-dto";
import { JiraIssue } from "src/response-time-tracking-jira/models/issue.entity";
import { Repository } from "typeorm";

@Injectable()
export class IssueService {

    constructor( @InjectRepository(JiraIssue)
    private usersRepository: Repository<JiraIssue>){

    }

    async get(api: string, ...rest: any) {
    
   
        const url = `${process.env.JIRA_HOST}/rest/api/3`;
        //console.log('Underlying url is: '+url);
        const result = await axios(`${url}/${api}`, {
          method: 'GET',
          headers: {
            Authorization: `Basic ${'am9kb2hleDc0NkB0b25hZXRvLmNvbTppNUhQVGpTT2NHSmlRNnF1dlgwSDAwRDY='}`,
            Accept: 'application/json',
          },
        });
    
        console.log('Received result : '+result.data);
        return result;
    }
  
     async post(api: string, bodyData: any, ...rest: any) {
      const url = `${process.env.JIRA_HOST}/rest/api/3`;
      const result = await axios(`${url}/${api}`, {
        method: 'POST',
        data: bodyData,
        headers: {
        //   Authorization: `Basic ${Buffer.from(
        //     `${process.env.JIRA_EMAIL_ADDRESS}:${process.env.JIRA_API_KEY}`,
        //   ).toString('base64')}`,
          Authorization: `Basic ${'am9kb2hleDc0NkB0b25hZXRvLmNvbTppNUhQVGpTT2NHSmlRNnF1dlgwSDAwRDY='}`,
          Accept: 'application/json',
        },
      });

    //   for (const issue of result.data.issues) {

    //   }
        let arrayOfCustomObject = [];
        try {

            for (let issueItem of result.data.issues) {
                let x = {
                    // 'id': issueItem.id,
                    'key': issueItem.key,
                    'summary': issueItem.fields.summary,
                    'changelog': []
                }

                issueItem.changelog?.histories.forEach((history) => {
                    x.changelog.push(history.items);
                });

                x.changelog = x.changelog.flat();
                arrayOfCustomObject.push(x);

            }
            console.log("Hello Its there");
            console.log(arrayOfCustomObject[0]);
            return this.usersRepository.save(arrayOfCustomObject);    
        }
        catch (err) {
            console.log(err);
        }

      //return result;
      
    }

    // async createIssue (createUserDto? : CreateIssueDto) : Promise<JiraIssue> {

    //     const issueObjArr = [];

    //     const issueObj = {
    //         summary: "Vishnu",
    //         key: 1,
    //         changelog: []
    //     };
    //     // const userDto = new CreateUserDto();
    //     // userDto
    //     return this.usersRepository.save(issueObj);
    // }

}